$(document).ready(function(){
	$.ajax({
		url: "http://rajeevpantha.000webhostapp.com/data.php",
		method: "GET",
		success: function(data) {
			console.log(data);
			var date = [];
			var waterlevel = [];

			for(var i in data) {
				date.push(data[i].date);
				waterlevel.push(data[i].waterlevel);
			}

			var chartdata = {
				labels: date,
				datasets : [
					{
						label: 'Water-Level',
						backgroundColor: 'rgba(94,174,235, 0.75)',
						borderColor: 'rgba(94,174,235, 0.75)',
						hoverBackgroundColor: 'rgba(94,174,235, 1)',
						hoverBorderColor: 'rgba(94,174,235, 1)',
						data: waterlevel
					}
				]
			};

			var ctx = $("#mycanvas");

			var barGraph = new Chart(ctx, {
				type: 'line',
				data: chartdata
			});
		},
		error: function(data) {
			console.log(data);
		}
	});
});