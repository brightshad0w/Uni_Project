<?php include("header.php");?>


<title>SplashData| Graph</title>

<h2 align="center"> Average Water level of Last 7 Days </h2>
<body onload="myFunction()" style="height: auto; padding-top: 75px; padding-bottom: 100px; background: white; margin: 0 auto; width: 80%;" >
    <div id="loader"></div>
<br /><br />

<div class="panel-group">
<div class="panel panel-default">
<div class="panel-heading" align="center"><h3>Water-Level Monitoring System</h3></div>
<div class="panel-body">
<div class="container-fluid">
<div class="row">
<div class="col-sm-12">

<canvas id="mycanvas"></canvas></div>

</div>
</div>

</div>
</div></div>
<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/Chart.min.js"></script>
<script type="text/javascript" src="js/graph.js"></script>
</body>
</html>
<?php include("footer.html");?>
