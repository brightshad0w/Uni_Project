<?php
    ob_start();
    session_start();
	$server = "localhost";
	$user = "id3073311_team_splash";
	$password = "splash22";
	$dbname = "id3073311_splash_db";
	
	$db = mysqli_connect($server, $user, $password,$dbname) or die ("could not connect to mysql");
?>