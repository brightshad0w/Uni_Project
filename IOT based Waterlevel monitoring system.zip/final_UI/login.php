<?php
include_once('dbconnect.php');
if(isset($_SESSION['usr_id'])!="") {
	header("Location: index.php");
}
//check if form is submitted
if (isset($_POST['login'])) {

	$email = mysqli_real_escape_string($db,$_POST['email']);
	$password = mysqli_real_escape_string($db,$_POST['password']);
	$pass = md5($password);
	$result = mysqli_query($db,"SELECT * FROM users WHERE email = '" . $email. "' and password = '" . md5($password). "'");

	if ($row = mysqli_fetch_array($result)) {
		$_SESSION['usr_id'] = $row['id'];
		$_SESSION['usr_name'] = $row['uname'];
		header("Location: home.php");
	} else {
		$errormsg = "Incorrect Email or Password!!!";
	}
}
?>
