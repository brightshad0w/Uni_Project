<?php
header('Access-Control-Allow-Origin: *');
//setting header to json
header('Content-Type: application/json');
include("dbconnect.php");

//getting last seven days
$query1 = sprintf("SELECT DISTINCT date from records ORDER BY id DESC LIMIT 7 ");
$result1 = $db->query($query1);
$dates = array();
foreach ($result1 as $d)
{
	$dates[] = $d;
}

//getting average from last 7 days
$temp = array();
$temp2 = array();
for($i = 0; $i<7; $i++)
{
    $query2 = sprintf("SELECT AVG(waterlevel) from records where date = '".implode("",$dates[$i])."'");
    $average = $db->query($query2);
    $avg = array();
    foreach($average as $a)
    {
        $avg[] = $a; //getting the actual average value from array
    }
    
    $temp[$i] = $avg; //storing value in array
    foreach($temp[$i] as $t)
    {
        $temp2[] = $t; //getting only the average value from the deepest array
    }
    
    
}

$temp3 = array();

for($i=0; $i<7; $i++)
{
    //setting value for specific tag
    $temp3[$i] = array(
        'date' => implode("",$dates[$i]),
        'waterlevel' => implode("",$temp2[$i]) 
        );
}

$data = array();

foreach($temp3 as $t)
{
    $data[] = $t; //getting data from temp3 and storing to data
}
echo json_encode($data);

//free memory
$result1->close();
$average->close();

//close connection
$db->close(); 

?>