<?php 
    include_once('dbconnect.php');
    include("header.php");
    
//getting last seven days
$query1 = sprintf("SELECT DISTINCT date from records ORDER BY id DESC LIMIT 7 ");
$result1 = $db->query($query1);
$dates = array();
foreach ($result1 as $d)
{
	$dates[] = $d;
}
?>


<style>
    body {
  margin-top: 30px;
}

.container {
  max-width: 960px;
}

.panel-default>.panel-heading {
  color: #333;
  background-color: #fff;
  border-color: #e4e5e7;
  padding: 0;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

.panel-default>.panel-heading a {
  display: block;
  padding: 10px 15px;
}

.panel-default>.panel-heading a:after {
  content: "";
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  font-style: normal;
  font-weight: 400;
  line-height: 1;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  float: right;
  transition: transform .25s linear;
  -webkit-transition: -webkit-transform .25s linear;
}

.panel-default>.panel-heading a[aria-expanded="true"] {
  background-color: #eee;
}

.panel-default>.panel-heading a[aria-expanded="true"]:after {
  content: "\2212";
  -webkit-transform: rotate(180deg);
  transform: rotate(180deg);
}

.panel-default>.panel-heading a[aria-expanded="false"]:after {
  content: "\002b";
  -webkit-transform: rotate(90deg);
  transform: rotate(90deg);
}

.accordion-option {
  width: 100%;
  float: left;
  clear: both;
  margin: 15px 0;
}

.accordion-option .title {
  font-size: 20px;
  font-weight: bold;
  float: left;
  padding: 0;
  margin: 0;
}

.accordion-option .toggle-accordion {
  float: right;
  font-size: 16px;
  color: #6a6c6f;
}

.accordion-option .toggle-accordion:before {
  content: "Expand All";
}

.accordion-option .toggle-accordion.active:before {
  content: "Collapse All";
}
</style>

<script>
    $(document).ready(function() {

  $(".toggle-accordion").on("click", function() {
    var accordionId = $(this).attr("accordion-id"),
      numPanelOpen = $(accordionId + ' .collapse.in').length;
    
    $(this).toggleClass("active");

    if (numPanelOpen == 0) {
      openAllPanels(accordionId);
    } else {
      closeAllPanels(accordionId);
    }
  })

  openAllPanels = function(aId) {
    console.log("setAllPanelOpen");
    $(aId + ' .panel-collapse:not(".in")').collapse('show');
  }
  closeAllPanels = function(aId) {
    console.log("setAllPanelclose");
    $(aId + ' .panel-collapse.in').collapse('hide');
  }
     
});
</script>

<title>SplashData | History</title>
<h2 class style="margin-top: 100px;" align="center">SPLASH Data History</h2>

<div class="container">
  <div class="accordion-option">
    <a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
  </div>
  <div class="clearfix"></div>
  <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
      
    <?php 
    for($i=0; $i<sizeof($dates); $i++)
    { ?>
    <div class="panel panel-default">
      <div class="panel-heading" role="tab" id="heading<?php echo $i;?>">
        <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $i;?>" aria-expanded="true" aria-controls="collapse<?php echo $i;?>">
          <?php echo implode("",$dates[$i]); ?>
        </a>
      </h4>
      </div>
      <div id="collapse<?php echo $i;?>" class="panel-collapse collapse out" role="tabpanel" aria-labelledby="heading<?php echo $i;?>">
        <div class="panel-body">
            
            <table class="table table-hover">
                <thead>
                        <tr>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Water Level</th>
                            <th>Humidity</th>
                            <th>Temperature</th>
                        </tr>
                </thead>
                <tbody>
                    <?php
            $result = mysqli_query($db,"SELECT * FROM records WHERE date = '".implode("",$dates[$i])."' ORDER BY id DESC");
            while($row = mysqli_fetch_array($result))
            {
            ?>
                    <tr>
                        <td><?php echo $row['date']; ?></td>
                        <td><?php echo $row['time']; ?></td>
                        <td><?php echo $row['waterLevel']; ?>%</td>
                        <td><?php echo $row['humidity']; ?>%</td>
                        <td><?php echo $row['temperature']; ?>°C</td>
                    </tr>
            <?php } ?>
                </tbody>
            </table>
        </div>
      </div>
    </div>
   <?php } ?>


<?php
    include('footer.html');
?>
    