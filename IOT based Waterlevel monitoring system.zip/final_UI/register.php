<?php
//session_start();
include_once('dbconnect.php');
include("header.php");
$error = false;

if (isset($_POST['signup'])) {
	$uname = mysqli_real_escape_string($db,$_POST['uname']);
	$email = mysqli_real_escape_string($db,$_POST['email']);
	$password = mysqli_real_escape_string($db,$_POST['password']);
	$cpassword = mysqli_real_escape_string($db,$_POST['cpassword']);
	
	
		if (!preg_match("/^[a-zA-Z ]+$/",$uname)) {
			$error = true;
			$name_error = "Name must contain only alphabets and space";
		}
		if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
			$error = true;
			$email_error = "Please Enter Valid Email ID";
		}
		if(strlen($password) < 6) {
			$error = true;
			$password_error = "Password must be minimum of 6 characters";
		}
		if($password != $cpassword) {
			$error = true;
			$cpassword_error = "Password and Confirm Password doesn't match";
		}
		if (!$error) {
			if(mysqli_query($db,"INSERT INTO users(uname,email,password) VALUES('" . $uname . "', '" . $email . "', '" . md5($password) . "')")) {

				$successmsg = "Successfully Registered ! ";
			} else {
				$errormsg = "Error in registering...Please try again later!";
			}
		}
}
?>

<html>
<head>
	<title>SplashData | Register</title>
	<meta content="width=device-width, initial-scale=1.0" name="viewport" >
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
</head>
<body style="height:100%; padding-top:90px; padding-bottom:50px; background: white; margin: 0 auto; width: 98%;">

<div class="container" style="padding-bottom:60px;">
	<div class="row">
		<div class="col-md-4 col-md-offset-4 well">
			<form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="signupform">
				<fieldset>
					<legend>Register your SPLASH Account</legend>

					<div class="form-group">
						<label for="uname">Name</label>
						<input type="text" name="uname" placeholder="Enter Full Name" required value="<?php if($error) echo $uname; ?>" class="form-control" />
						<span class="text-danger"><?php if (isset($name_error)) echo $name_error; ?></span>
					</div>

					<div class="form-group">
						<label for="email">Email</label>
						<input type="text" name="email" placeholder="Email" required value="<?php if($error) echo $email; ?>" class="form-control" />
						<span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span>
					</div>

					<div class="form-group">
						<label for="password">Password</label>
						<input type="password" name="password" placeholder="Password" required class="form-control" />
						<span class="text-danger"><?php if (isset($password_error)) echo $password_error; ?></span>
					</div>

					<div class="form-group">
						<label for="cpassword">Confirm Password</label>
						<input type="password" name="cpassword" placeholder="Confirm Password" required class="form-control" />
						<span class="text-danger"><?php if (isset($cpassword_error)) echo $cpassword_error; ?></span>
					</div>
						
					<div class="form-group">
						<input type="submit" name="signup" value="Sign Up" class="btn btn-primary"/>
					</div>
					<div>
						Already Registered? <a href="index.php">Login Here</a>
					</div>
				</fieldset>
			</form>
			<span class="text-success"><?php if (isset($successmsg)) { echo $successmsg; } ?></span>
			<span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
		</div>

	</div>
	</div>
</div>
<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>

<?php include("footer.html");?>
