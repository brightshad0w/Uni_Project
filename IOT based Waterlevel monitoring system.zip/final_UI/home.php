<?php
include_once ('dbconnect.php');
include ("header.php");

$result = mysqli_query($db,"SELECT * FROM records ORDER BY id DESC LIMIT 1");
$row = mysqli_fetch_array($result);

$temperature = $row['temperature'];
$humidity = $row['humidity'];
$waterlevel = $row['waterLevel'];
$date = $row['date'];
$time = $row['time'];

$errmsg = "Check device status for correct reading !!";
	?>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<title>SplashData| Home</title>

<meta name="viewport" content="width=device-width, initial-scale=1">



</head>
<body onload="myFunction()" style="height: 100%; padding-top: 50px; background: white; margin: 0 auto; width: 100%;">
<div id="loader"></div>


<?php if (isset ( $_SESSION ['usr_id'] )) {?>
<div id = "animate-bottom" class="container" style="padding-bottom: 50px;" >
  <h2 style="padding-top:20px;font-family:Century Gothic, CenturyGothic, Geneva, AppleGothic, sans-serif;color: black;" align="center">SPLASH Data</h2><br>
  <span style="font-family:Century Gothic, CenturyGothic, Geneva, AppleGothic, sans-serif;color: grey;" align="center">(last updated: <?php echo $date. ', '.$time?>)</span>
  
  <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading" align="center"><h3>Water-Level Monitoring System</h3></div>
      <div class="panel-body">
      <div class="container-fluid">      
  <div class="row">
    <div class="col-sm-6">
    <h1 align="center">Temperature</h1>
    <?php if($temperature<=10){?>
     <center><img class="img-responsive" src="images/lowtemp.png" height="200" width="150">
     </center> <?php }else if($temperature>10&&$temperature<=40){?> 
     <center><img class="img-responsive" src="images/midtemp.png" height="200" width="150">
     </center> <?php }else if($temperature>40){?> 
     <center><img class="img-responsive" src="images/hightemp.png" height="200" width="150">
     </center> <?php }?>
     <p align="center" style="font-size:40px"> <?php echo $temperature;?> °C </p> 
    </div>
    <div class="col-sm-6">
    <h1 align="center" >Humidity</h1>
    <center><img class="img-responsive" src="images/humidity.png" height="200" width="150">
     </center>
     <p align="center" style="font-size:40px"> <?php echo $humidity;?> %</p>  
    </div></div>
    <hr />
    <div class="row">
    <div class="col-sm-12">
    <h1 align="center">Water Level</h1>
    <?php if($waterlevel<=10){?>
     <center><img class="img-responsive" src="images/10.png" height="200" width="150">
     <p align="center" style="font-size:40px"> <?php echo $waterlevel;?> %</p>
     <h3 style="color: red;"> Very Low, Please Refill !! </h3></center> 
     <?php }else if($waterlevel>10 && $waterlevel<=20){?>
     <center><img class="img-responsive" src="images/20.png" height="200" width="150">
     <p align="center" style="font-size:40px"> <?php echo $waterlevel;?> %</p>
     <h3> Low </h3></center> 
     <?php }else if($waterlevel>20 && $waterlevel<=40){?>
     <center><img class="img-responsive" src="images/40.png" height="200" width="150">
     <p align="center" style="font-size:40px"> <?php echo $waterlevel;?> %</p>
     <h3> Meduim </h3></center> 
     <?php } else if($waterlevel>40 && $waterlevel<=60){?>
     <center><img class="img-responsive" src="images/60.png" height="200" width="150">
     <p align="center" style="font-size:40px"> <?php echo $waterlevel;?> %</p>
     <h3> Half Tank </h3></center>
     <?php }else if($waterlevel>60 && $waterlevel<=80){?>
     <center><img class="img-responsive" src="images/80.png" height="200" width="150">
     <p align="center" style="font-size:40px"> <?php echo $waterlevel;?> %</p>
     <h3> High </h3></center> 
     <?php }else if($waterlevel>80 && $waterlevel<=100){?>
     <center><img class="img-responsive" src="images/100.png" height="200" width="150">
     <p align="center" style="font-size:40px;"> <?php echo $waterlevel;?> %</p>
     <h3 style="color: red;"> Tank Almost Full!! </h3></center> <?php }else { echo '<script type="text/javascript">alert("' . $errmsg . '")</script>';?>
     <center><h3 style="color: red;font-size:40px"> ERROR !! <?php }?>
     <center><strong><a href="graph.php">View in Graph</a></strong></center>
     <center><strong><a href="history.php">View Data History</a></strong></center>
    </center>
          
    </div>
  </div>
</div>
      
      </div>
    </div>

  </div>
</div>
<?php }else echo "Please sign in !!";	?>
</body>
</html>
<?php
include("footer.html");?>