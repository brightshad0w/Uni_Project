<?php
include_once('dbconnect.php');
date_default_timezone_set('Australia/Melbourne');
 
//Receive the RAW post data.
$content = trim(file_get_contents("php://input"));
$json = json_decode($content);

//filtering of json data
$temperature = $json ->{'payload_fields'} -> {'temperature'};
$humidity = $json ->{'payload_fields'} -> {'humidity'};
$waterLevel = $json ->{'payload_fields'} -> {'waterLevel'};
$date = date('Y/m/d');
$time = date('H:i:s');

$payload = array (
	'from' => 'Splash',
    'to'=> '+61410424154',
    'text'=> '--Splash Water Level Monitoring System--'. ' Water Level: '.$waterLevel.'% Humidity: '.$humidity.'% Temperature: '.$temperature.' C',
    'api_key' => '600ac66a',
    'api_secret' => '2b50145160f99cd6'
);

//encoding the json data
$jsonDataEncoded = json_encode($payload);

//API url
$url = 'https://rest.nexmo.com/sms/json';

//initiate cURL
$ch = curl_init($url);
	 
//Tell cURL that we want to send a POST request.
curl_setopt($ch, CURLOPT_POST, 1);
	 
//Attach our encoded JSON string to the POST fields.
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
	 
//Set the content type to application/json
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
	 
//Execute the request
$result = curl_exec($ch);

mysqli_query($db,"INSERT INTO records(date,time,waterLevel,humidity,temperature) VALUES('" . $date . "', '" . $time . "', ".$waterLevel. "," .$humidity."," .$temperature. ")")
or die (mysqli_error($db));

//remove the comment for debugging
//echo $jsonDataEncoded;




?>