<?php 
include_once('dbconnect.php');
include("header.php");
if(isset($_SESSION['usr_id'])){
	include("home.php");}else{
	include("login.php");?>
<html>
<title>SplashData| Home</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<style>
  #overlay {
    width: 100%;
    height: 100%;
	background: url(images/background.png) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
	background-size: cover;
	
  }

	#login{
		float: right;
		margin-right: 20px;
	}
	
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 120px;
  height: 120px;
  -webkit-animation: spin 0.25s linear infinite;
  animation: spin 0.75s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* Add animation to "page content" */
#animate-bottom {
  position: relative;
  -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 0.8s;
  animation-name: animatebottom;
  animation-duration: 0.8s
  display: none;
  text-align: center;
}

@-webkit-keyframes animatebottom {
  from { bottom:-100px; opacity:0 } 
  to { bottom:0px; opacity:1 }
}

@keyframes animatebottom { 
  from{ bottom:-100px; opacity:0 } 
  to{ bottom:0; opacity:1 }
}

</style>
<script>
var myVar;

function myFunction() {
    myVar = setTimeout(showPage, 700);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
</script>
		
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link href="css/navbar.css" rel="stylesheet">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		</head>
		<body id='overlay' onload="myFunction()" style="margin: 0 auto; width: 100%; height:100%; padding-top:50px;" >
				<div id="loader"></div>
				<div id = "animate-bottom" class="container" >
					<div class="col-lg-4" id="login" style="padding-bottom:50px;">
					<h2 style="padding-top:40px;font-family:Century Gothic, CenturyGothic, Geneva, AppleGothic, sans-serif;color: black;" align="center">Login / Register</h2>
				<h4 align="center" style="font-family:Century Gothic, CenturyGothic, Geneva, AppleGothic, sans-serif;color: black;"> Sign In to monitor SPLASH data</h4>
				
								<div class="container-fluid" style="padding-top:20px;">
										<div class="row text-center">
											<div class="col-md-16 col-md-offset-16 well" >
												<form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="loginform">
													<fieldset>
														<legend style="text-align:center;">Login</legend>

														<div class="form-group">
															<label for="name">Email</label>
															<input type="text" name="email" placeholder="Your Email" required class="form-control" />
														</div>

														<div class="form-group">
															<label for="name">Password</label>
															<input type="password" name="password" placeholder="Your Password" required class="form-control" />
														</div>

														<div class="form-group">
															<input type="submit" name="login" value="Login" class="btn btn-success" />																														</div>															<div class="container-fluid text-center">																	New User? <a style="color:##3B5998;" href="register.php">Sign Up Here</a>																</div>
														
													</fieldset>
												</form>
												<span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
											</div>
										</div>
									</div>
							</div>
					</div>
				
				<!-- jQuery -->
				<script src="js/jquery.js"></script>

				<!-- Bootstrap Core JavaScript -->
				<script src="js/bootstrap.min.js"></script>

				<!-- Scrolling Nav JavaScript -->
				<script src="js/jquery.easing.min.js"></script>

</body>
</html>
<?php }
include("footer.html"); 
	?>